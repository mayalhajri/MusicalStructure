package com.example.android.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.net.Uri;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView news1 = (ImageView) findViewById(R.id.news);
        ImageView news2 = (ImageView) findViewById(R.id.interview);
        ImageView news3 = (ImageView) findViewById(R.id.album1news);
        ImageView news4 = (ImageView) findViewById(R.id.album2News);
        ImageView news5 = (ImageView) findViewById(R.id.competition);
        Button homeHome = (Button) findViewById(R.id.homeHome);
        Button homeAlbum = (Button) findViewById(R.id.homeAlbum);
        Button homeStor = (Button) findViewById(R.id.homeStore);

        news1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("http://www.music-news.com/news/UK/106918/Princess-of-China-How-Rihanna-s-2015-Met-Gala-still-steals-the-show");
                Intent news1_intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(news1_intent);
            }
        });
        news2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri2 = Uri.parse("http://www.music-news.com/review/UK/12379/Interview/Collabro");
                Intent news2_intent = new Intent(Intent.ACTION_VIEW, uri2);
                startActivity(news2_intent);
            }
        });
        news3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri3 = Uri.parse("http://www.music-news.com/review/UK/12653/Album/Hafdis-Huld");
                Intent news3_intent = new Intent(Intent.ACTION_VIEW, uri3);
                startActivity(news3_intent);
            }
        });
        news4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri4 = Uri.parse("http://www.music-news.com/review/UK/12657/Album/Shaman-s-Harvest");
                Intent news4_intent = new Intent(Intent.ACTION_VIEW, uri4);
                startActivity(news4_intent);
            }
        });

        news5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri5 = Uri.parse("http://www.music-news.com/competition/4842/Win-tickets-to-see-Leee-John-at-The-Jazz-Cafe");
                Intent news5_intent = new Intent(Intent.ACTION_VIEW, uri5);
                startActivity(news5_intent);
            }
        });
        homeHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeHome_intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(homeHome_intent);
            }
        });
        homeAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeAlbum_intent = new Intent(MainActivity.this, Album.class);
                startActivity(homeAlbum_intent);
            }
        });

        homeStor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeStor_intent = new Intent(MainActivity.this, stor.class);
                startActivity(homeStor_intent);
            }
        });
    }
}

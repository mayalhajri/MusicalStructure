package com.example.android.musicalstructure;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class Album extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);
        LinearLayout album1 = (LinearLayout) findViewById(R.id.album1);
        LinearLayout album6 = (LinearLayout) findViewById(R.id.album6);
        Button homeAlbum = (Button) findViewById(R.id.homeAlbum);
        Button albumAlbum = (Button) findViewById(R.id.albumAlbum);
        Button storAlbum = (Button) findViewById(R.id.storAlbum);
        album1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent album1_intent = new Intent(Album.this, SelenAlbumDateils.class);
                startActivity(album1_intent);
            }
        });
        album6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent album6_intent = new Intent(Album.this, stor.class);
                startActivity(album6_intent);
            }
        });
        homeAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeAlbum_intent = new Intent(Album.this, MainActivity.class);
                startActivity(homeAlbum_intent);
            }
        });
        albumAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent albumAlbum_intent = new Intent(Album.this, Album.class);
                startActivity(albumAlbum_intent);
            }
        });

        storAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent storAlbum_intent = new Intent(Album.this, stor.class);
                startActivity(storAlbum_intent);
            }
        });
    }
}

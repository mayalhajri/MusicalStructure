package com.example.android.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class SelenAlbumDateils extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selen_album_dateils);
        ImageView play = (ImageView) findViewById(R.id.playbuttonS);
        Button selenHome = (Button) findViewById(R.id.SelenHome);
        Button selenAlbum = (Button) findViewById(R.id.SelenAlbum);
        Button selenStore = (Button) findViewById(R.id.SelenStore);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent play_intent = new Intent(SelenAlbumDateils.this, playActivity.class);
                startActivity(play_intent);
            }
        });
        selenHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent selenHome_intent = new Intent(SelenAlbumDateils.this, MainActivity.class);
                startActivity(selenHome_intent);
            }
        });
        selenAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent selenAlbum_intent = new Intent(SelenAlbumDateils.this, Album.class);
                startActivity(selenAlbum_intent);
            }
        });

        selenStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent selenStore_intent = new Intent(SelenAlbumDateils.this, stor.class);
                startActivity(selenStore_intent);
            }
        });
    }
}

package com.example.android.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class stor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stor);
        Button storeHome = (Button) findViewById(R.id.storeHome);
        Button storeAlbum = (Button) findViewById(R.id.storeAlbum);
        Button storeStore = (Button) findViewById(R.id.storeStor);
        storeHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent storeHome_intent = new Intent(stor.this, MainActivity.class);
                startActivity(storeHome_intent);
            }
        });
        storeAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent storeAlbum_intent = new Intent(stor.this, Album.class);
                startActivity(storeAlbum_intent);
            }
        });

        storeStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent storeStore_intent = new Intent(stor.this, stor.class);
                startActivity(storeStore_intent);
            }
        });
    }
}

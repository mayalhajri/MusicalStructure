package com.example.android.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class playActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        Button playHome = (Button) findViewById(R.id.playHome);
        Button playAlbum = (Button) findViewById(R.id.playAlbum);
        Button playStor = (Button) findViewById(R.id.playStor);
        playHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent playHome_intent = new Intent(playActivity.this, MainActivity.class);
                startActivity(playHome_intent);
            }
        });
        playAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent playAlbum_intent = new Intent(playActivity.this, Album.class);
                startActivity(playAlbum_intent);
            }
        });

        playStor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent playStor_intent = new Intent(playActivity.this, stor.class);
                startActivity(playStor_intent);
            }
        });
    }
}

